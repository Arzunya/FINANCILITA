/*
package FinancilitaServerlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import FinancilitaBean.DespesaBean;
import FinancilitaBean.InvestBean;
import FinancilitaBean.ReceitaBean;
import FinancilitaDAO.*;
import FinancilitaDAO.*;
import FinancilitaDAO.*;
import FinancilitaException.DBException;
import FinancilitaFactoryDAO.ReceitaFactoryDAO;
import FinancilitaDAOImp.copy.*;


@WebServlet("/listagem")

public class teste extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ReceitaDAO dao;
	private DespesaDao dao1;
	private InvestDAO dao2;


	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	
		
		List<ReceitaBean> lista = dao.listar();
		request.setAttribute("receita", lista);
		request.getRequestDispatcher("dashboard.jsp").forward(request, response);
		
		List<DespesaBean> lista2 = dao1.listar();
		request.setAttribute("despesa", lista2);
		request.getRequestDispatcher("dashboard.jsp").forward(request, response);
		
		List<InvestBean> lista1 = dao2.listar();
		request.setAttribute("investimento", lista1);
		request.getRequestDispatcher("dashboard.jsp").forward(request, response);
		
		
		

}}
*/